---
layout: default
title: Categories
---

<div class="post">
	<h1 class="pageTitle">Categories</h1>
	<ul><font size="5">
		<li><a href="{{site.url}}/etc">etc</a></li>
		<li><a href="{{site.url}}/slack">slack</a></li>
		<li><a href="{{site.url}}/go">Go</a></li>
		<li><a href="{{site.url}}/git">Git</a></li>
		<li><a href="{{site.url}}/docker">docker</a></li>
		</font>
	</ul>
</div>
